import{E as a}from"./index-nsjw58Bn.js";function c(e){return e.charCodeAt(0)===65279?e.slice(1):e}function p(e){const t=[];let n=[],i="",o=!1,s=0;const f=()=>{n.push(i),i=""},l=()=>{f(),t.push(n),n=[]};for(;s<e.length;){const r=e[s];o?r==='"'?e[s+1]==='"'?(i+='"',s+=2):(o=!1,s+=1):(i+=r,s+=1):r==='"'&&i===""?(o=!0,s+=1):r===","?(f(),s+=1):r==="\r"?(l(),s+=e[s+1]===`
`?2:1):r===`
`?(l(),s+=1):(i+=r,s+=1)}return(i!==""||n.length>0)&&l(),t}function d(e){return e.map(t=>t.map(n=>/[",\r\n]/.test(n)?`"${n.replace(/"/g,'""')}"`:n).join(",")).join(`\r
`)}function h(e,t,n="text/csv;charset=utf-8;"){a(e,t,n)}export{d as a,h as d,p,c as s};
