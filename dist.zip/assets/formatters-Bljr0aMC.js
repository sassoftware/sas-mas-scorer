function n(r){if(!r)return"N/A";try{return new Date(r).toLocaleString()}catch{return r}}function e(r,t){return r.length<=t?r:r.slice(0,t-1)+"…"}export{n as f,e as t};
