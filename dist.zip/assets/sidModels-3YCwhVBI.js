import{s}from"./index-DV5ooSPn.js";async function t(e){return(await s.get(`/modelRepository/models/${e}`,{headers:{Accept:"application/vnd.sas.models.model+json"}})).data}export{t as g};
